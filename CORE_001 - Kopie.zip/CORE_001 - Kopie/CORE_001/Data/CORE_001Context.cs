﻿using CORE_001.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CORE_001.Data
{
    public class CORE_001Context : DbContext
    {
        public CORE_001Context(DbContextOptions<CORE_001Context> options)
            : base(options)
        {

        }
        public DbSet<Movie> Movie { get; set; }
    }
}
