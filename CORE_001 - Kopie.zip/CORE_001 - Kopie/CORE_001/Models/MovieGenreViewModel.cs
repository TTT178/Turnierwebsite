﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CORE_001.Models
{
    public class MovieGenreViewModel
    {
    }
}
